Benchmarks that measure various PC-98 blitting approaches. The source code is
part of the ReC98 repository at

	https://github.com/nmlgc/ReC98

inside the `Research/` directory.
The `xfade` tests additionally need two .PI image files named `MS4.PI` and
`MS5.PI` in the current directory.

More info can be found at the respective ReC98 blog posts:

	• https://rec98.nmlgc.net/blog/2023-03-05 (`ifshf`)
	• https://rec98.nmlgc.net/blog/2025-09-10 (`pi_bench`, `wide`, `xfade`)
