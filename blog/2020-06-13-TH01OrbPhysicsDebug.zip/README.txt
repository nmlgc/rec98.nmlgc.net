This came out of the latest reverse-engineering results by the ReC98 project.
The necessary code modifications to achieve this debug output can be found at

	https://github.com/nmlgc/ReC98/commit/874fe6db8a1a40f978b344ed7d400bbedd7ca0a3

To use, simply replace TH01's REIIDEN.EXE with the included one, and run the
game in debug mode, via

	game d

on the DOS prompt.
