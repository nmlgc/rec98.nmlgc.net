This came out of the latest reverse-engineering results by the ReC98 project.
The necessary code modifications to achieve this boss rush can be found at

	https://github.com/nmlgc/ReC98/commit/cf9f6297fa2e5e96f5819d5a26a7d40d57f9124d

To apply, simply replace TH05's MAIN.EXE with the included one.
