This came out of the latest reverse-engineering results by the ReC98 project.
The necessary code modifications to achieve collision bitmap rendering can be
found, in order, at

	https://github.com/nmlgc/ReC98/commit/40147ee4e980057220315a432c71b4a21a178726
	https://github.com/nmlgc/ReC98/commit/860536c16593c90da0e05fbce3031a1c73ce7ad6
	https://github.com/nmlgc/ReC98/commit/9ca93b98d3f6833283cf713bc65f408aec83ff23

To use, simply replace TH03's MAIN.EXE with the included one.

More information about this game's collision detection:

	https://rec98.nmlgc.net/blog/2022-02-18
