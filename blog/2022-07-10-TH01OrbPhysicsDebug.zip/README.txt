In TH01's debug mode, this mod displays:
• Physics values for the Yin-Yang Orb at the bottom center of the playfield
• The frames since the last collision with every bumper bar in the top-left
  corner of the respective stage object tile

This binary was built from the ReC98 `th01_orb_debug` branch:

	https://github.com/nmlgc/ReC98/tree/th01_orb_debug

To use, simply replace TH01's REIIDEN.EXE with the included one, and run the
game in debug mode, via

	game d

on the DOS prompt.
