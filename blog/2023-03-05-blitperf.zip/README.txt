A benchmark that measures various PC-98 blitting approaches. The source code is
part of the ReC98 repository at

	https://github.com/nmlgc/ReC98

See the summary blog post at https://rec98.nmlgc.net/blog/2023-03-04 for more
info.
