NOTE:This is a pre-release build. This version is not representative of the final product
and things are subject to change.

NOTE 2: Character select controls are still the old TB(up and down) and Z/X (selection).
This will change in a newer version.

This patch modifies Player 1's keyboard controls in Human-vs-Human Multiplayer.
They are as follows:

WASD - Movement
O - Shoot/Charge
P - Bomb

Player 2's controls are unchanged. They are:
Numpad 8,2,4,6 - Movement
Left Arrow - Shoot/Charge
Right Arrow - Bomb



Have fun.


Patch Developed by spaztron64.
PC-98x1 Keyboard Memory Map, ReC98 and other resources provided by nmlgc.