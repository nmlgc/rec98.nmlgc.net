Score files for all PC-98 Touhou games that unlock everything, but don't
contain any recorded scores.

Source:

	https://rec98.nmlgc.net/blog/2021-12-27
