These patches came out of the latest reverse-engineering results by the ReC98
project. The necessary code modifications to achieve these fixes can be found
at

	https://github.com/nmlgc/ReC98/commit/a7ac71ade63db86af21696f6d6e1c1bd13778255
	https://github.com/nmlgc/ReC98/commit/0077b2db10439ecc94c7a31b250a3e4373ef00c7

I also took care to introduce as few code changes as possible, allowing these
modded executables to be easily diffed against the original unmodified release.

To use them, choose one of the two branches, and replace the corresponding
executables of the respective game with the included ones.

More information about the memory limits, and the TH04 no-EMS crash bug:

	https://rec98.nmlgc.net/blog/2021-11-29
