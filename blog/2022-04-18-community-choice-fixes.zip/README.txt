These binaries were built from the ReC98 `community_choice_fixes` branch:

	https://github.com/nmlgc/ReC98/tree/community_choice_fixes

This branch combines various bugfix mod branches developed as part of the ReC98
project. For crashes that result from originally undefined behavior, this
branch picks the most popular variant among the player community. Hence, these
are the generally recommended versions of playing the games as of April 2022.

The following fixes are included:

• `th03_no_gdc_frequency_check`: Allows TH03 to be run with the GDC clock set
  to 5 MHz. The original game enforces 2.5 MHz, but doesn't functionally
  require it, even on real hardware.
• `th04_noems_crash_fix`: Increases the self-imposed memory limit of TH04's
  MAIN.EXE by just the right amount to fix the crash at the beginning of the
  Stage 5 Yuuka boss fight if no EMS driver is installed.
• `th04_0_ring_as_single_bullet`: Works around the "Divide error" crash that
  can appear when fighting Kurumi on Easy Mode and with minimum rank. In this
  case, the broken pattern will fire a single bullet rather than trying to fire
  a 0-way ring.
• `th04_marisa4_crash_still`: Works around the "Divide error" crash that can
  appear during the Stage 4 Marisa boss fight, when destroying the last of her
  bits on a specific 4-frame window during two of her patterns. Instead of
  trying to move at infinite speed, Marisa will stay still for the last 8
  frames of the affected patterns.

To use, simply replace the game's original files with the included ones.

More information about TH04's no-EMS and Divide Error crash bugs, and the poll
results that went into choosing these fixes over the alternatives:

	https://rec98.nmlgc.net/blog/2021-11-29
	https://rec98.nmlgc.net/blog/2022-04-18
